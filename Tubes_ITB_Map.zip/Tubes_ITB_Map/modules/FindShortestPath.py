def isSafe(mat, visited, x, y, min_dist, dist):
  return (dist <= min_dist and x >= 0 and x < len(mat) and y >= 0 and y < len(mat[0]) and (mat[x][y] == 'J' or mat[x][y][0] == 'X') and (not visited[x][y]))


def findShortestPath(mat, visited, i, j, x, y, min_dist, dist, min_path, path):
  if (i == x and j == y):
    if min_dist < dist:
      return (min_dist, min_path)
    return (dist, path)

  # set (i, j) cell as visited
  visited[i][j] = True

  if (i <= x):
     # go to the bottom cell
    if (isSafe(mat, visited, i + 1, j, min_dist, dist + 1)):
      min_dist, min_path = findShortestPath(mat, visited, i + 1, j, x, y, min_dist, dist + 1, min_path, path + [(i+1,j)])
    if (j <= y):
      # go to the right cell
      if (isSafe(mat, visited, i, j + 1, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i, j + 1, x, y, min_dist, dist + 1, min_path,  path + [(i,j+1)])
      # go to the top cell
      if (isSafe(mat, visited, i - 1, j, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i - 1, j, x, y, min_dist, dist + 1, min_path,  path + [(i-1,j)])
      # go to the left cell
      if (isSafe(mat, visited, i, j - 1, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i, j - 1, x, y, min_dist, dist + 1, min_path,  path + [(i,j-1)])
    else:
      # go to the left cell
      if (isSafe(mat, visited, i, j - 1, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i, j - 1, x, y, min_dist, dist + 1, min_path,  path + [(i,j-1)])
      # go to the top cell
      if (isSafe(mat, visited, i - 1, j, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i - 1, j, x, y, min_dist, dist + 1, min_path,  path + [(i-1,j)])
      # go to the right cell
      if (isSafe(mat, visited, i, j + 1, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i, j + 1, x, y, min_dist, dist + 1, min_path,  path + [(i,j+1)])
  else:
    # go to the top cell
    if (isSafe(mat, visited, i - 1, j, min_dist, dist + 1)):
      min_dist, min_path = findShortestPath(mat, visited, i - 1, j, x, y, min_dist, dist + 1, min_path,  path + [(i-1,j)])
    if (j <= y):
      # go to the right cell
      if (isSafe(mat, visited, i, j + 1, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i, j + 1, x, y, min_dist, dist + 1, min_path,  path + [(i,j+1)])
      # go to the bottom cell
      if (isSafe(mat, visited, i + 1, j, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i + 1, j, x, y, min_dist, dist + 1, min_path, path + [(i+1,j)])
      # go to the left cell
      if (isSafe(mat, visited, i, j - 1, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i, j - 1, x, y, min_dist, dist + 1, min_path,  path + [(i,j-1)])
    else:
      # go to the left cell
      if (isSafe(mat, visited, i, j - 1, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i, j - 1, x, y, min_dist, dist + 1, min_path,  path + [(i,j-1)])
      # go to the bottom cell
      if (isSafe(mat, visited, i + 1, j, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i + 1, j, x, y, min_dist, dist + 1, min_path, path + [(i+1,j)])
      # go to the right cell
      if (isSafe(mat, visited, i, j + 1, min_dist, dist + 1)):
        min_dist, min_path = findShortestPath(mat, visited, i, j + 1, x, y, min_dist, dist + 1, min_path,  path + [(i,j+1)])

  # backtrack: remove (i, j) from the visited matrix
  visited[i][j] = False
  return (min_dist, min_path)
 

def findShortestPathLength(mat, src, dest):
  if ((mat[src[0]][src[1]][0] not in ['J','X']) or (mat[dest[0]][dest[1]][0] not in ['J', 'X'])):
    return (-1, [])

  row = len(mat)
  col = len(mat[0])

  if src[0] < dest[0]:
    temp = src
    src = dest
    dest = temp

  visited = [[None for _ in range(col)] for i in range(row)]

  dist = float("inf")
  path = [src]
  dist, path = findShortestPath(mat, visited, src[0],
                          src[1], dest[0], dest[1], dist, 0, path, path)

  if (dist != float("inf")):
    return (dist, path)
  return (-1, path)
