from modules.ITBMap import getOptimizedMatrix
from modules.PrintMap import printMap
from modules.FindShortestPath import findShortestPathLength
import os


def daftar_gedung():
  print('{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}'.format(
      "1. GKU 1", "2. GKU 2", "3. GKU 3", "4. Gerbang", "5. Gedung E", "6. Gedung C"))
  print('{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}'.format(
      "7. Mushola", "8. Toilet", "9. Danau", "10.Gedung D", "11.KOICA", "12.Rektorat"))
  print('{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}'.format("13.Labtek IA&IB",
        "14.Gedung A", "15.Gedung SBM", "16.Lap. Basket", "17.GSG", "18.GOR Futsal"))
  print('{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}'.format("19.Asrama TBI",
        "20.Asrama TBII", "21.Asrama TBIII", "22.Asrama TBIV", "23.Asrama TBV", "24.Lapangan"))
  print('{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}'.format("25.Labtek IIA",
        "26.Labtek IIB", "27.Screenhouse", "28.WTP", "29.Gedung Baca ", "30.Studio Kriya"))
  print('{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}{:<16s}'.format("31.Labtek IC",
        "32.Asrama Dosen", "33.IPST", "34.Labtek VA", "35.Labtek VB", "36.Labtek VC"))
  print('{:<16s}{:<16s}{:<16s}'.format(
      "37.Masjid ", "38.Kehutanan", "39.Amphiteater"))

def clear():
   os.system("cls||clear")

list_pintu = ["X-G1", "X-G2", "X-GK3", "X-GU", "X-GE", "X-GC", "X-MU", "X-TO", "X-D", "X-GD", "X-KIA", "X-R", "X-L3", "X-GA", "X-SBM", "X-LB", "X-GSG", "X-GF", "X-TB1",
              "X-TB2", "X-TB3", "X-TB4", "X-TB5", "X-L", "X-2A", "X-2B", "X-SH", "X-WTP", "X-GB", "X-ST", "X-LR", "X-AD", "X-IP", "X-VA", "X-VB", "X-VC", "X-JB", "X-KH", "X-AMP"]
koor_pintu = {'X-GF': (21, 55), 'X-L': (29, 32), 'X-TB1': (33, 49), 'X-GSG': (33, 63), 'X-TB2': (36, 45), 'X-TB3': (39, 40), 'X-WTP': (41, 7), 'X-TB4': (41, 35), 'X-SH': (43, 29), 'X-AMP': (45, 54), 'X-LB': (48, 65), 'X-2A': (49, 31), 'X-2B': (53, 33), 'X-SBM': (58, 41), 'X-GA': (59, 44), 'X-GK3': (59, 73), 'X-KIA': (61, 69), 'X-TB5': (62, 15), 'X-ST': (64, 40), 'X-GB': (64, 42), 'X-GC': (65, 49), 'X-MU': (66, 41), 'X-TO': (66, 43), 'X-GD': (70, 47), 'X-R': (70, 74), 'X-GE': (72, 42), 'X-LR': (78, 17), 'X-L3': (79, 26), 'X-G1': (84, 54), 'X-G2': (97, 31), 'X-IP': (105, 62), 'X-VA': (134, 67), 'X-KH': (136, 69), 'X-AD': (138, 47), 'X-VB': (139, 66), 'X-VC': (143, 67), 'X-D': (158, 9), 'X-JB': (159, 70), 'X-GU': (170, 1)}

clear()
print("   _____ ______ _               __  __       _______   _____       _______       _   _  _____ ")
print("  / ____|  ____| |        /\   |  \/  |   /\|__   __| |  __ \   /\|__   __|/\   | \ | |/ ____|")
print(" | (___ | |__  | |       /  \  | \  / |  /  \  | |    | |  | | /  \  | |  /  \  |  \| | |  __ ")
print("  \___ \|  __| | |      / /\ \ | |\/| | / /\ \ | |    | |  | |/ /\ \ | | / /\ \ | . ` | | |_ |")
print("  ____) | |____| |____ / ____ \| |  | |/ ____ \| |    | |__| / ____ \| |/ ____ \| |\  | |__| |")
print(" |_____/|______|______/_/    \_\_|  |_/_/    \_\_|    |_____/_/    \_\_/_/    \_\_| \_|\_____|")
# font : bulbhead, tab : 5x
print("                  _  _  ____    ____  ____  _____  ___  ____    __    __  __ ")
print("                 ( )/ )( ___)  (  _ \(  _ \(  _  )/ __)(  _ \  /__\  (  \/  )")
print("                  )  (  )__)    )___/ )   / )(_)(( (_-. )   / /(__)\  )    ( ")
print("                 (_)\_)(____)  (__)  (_)\_)(_____)\___/(_)\_)(__)(__)(_/\/\_)")
# font : Doom
print(" _   _   ___  _   _ _____ _____   ___ _____ ___________   _____ ___________     ___ _____ _   _ ")
print("| \ | | / _ \| | | |_   _|  __ \ / _ \_   _|  _  | ___ \ |_   _|_   _| ___ \   |_  |_   _| \ | |")
print("|  \| |/ /_\ \ | | | | | | |  \// /_\ \| | | | | | |_/ /   | |   | | | |_/ /     | | | | |  \| |")
print("| . ` ||  _  | | | | | | | | __ |  _  || | | | | |    /    | |   | | | ___ \     | | | | | . ` |")
print("| |\  || | | \ \_/ /_| |_| |_\ \| | | || | \ \_/ / |\ \   _| |_  | | | |_/ / /\__/ / | | | |\  |")
print("\_| \_/\_| |_/\___/ \___/ \____/\_| |_/\_/  \___/\_| \_|  \___/  \_/ \____/  \____/  \_/ \_| \_/")
print("")
print("")

loop1 = True
pertamaKali = True
while loop1 == True:
  selectionOne = "1"
  mapArr = getOptimizedMatrix()
  while selectionOne not in ["2", "3"]:
    if pertamaKali == True:
      print("Silakan input angka '1' atau '2'")
      print("1. Tampilkan peta ITB Jatinangor.")
      print("2. Program navigasi ITB Jatinangor")
      selectionOne = input("Input : ")
      print("----------------------------------------------------------------")
      if selectionOne == "2":
          pertamaKali = False
    else:
      print("Apakah ingin navigasi lagi?")
      print("1. Tampilkan peta ITB Jatinangor.")
      print("2. Ya")
      print("3. Tidak (tutup program)")
      selectionOne = input("Input : ")
      print("----------------------------------------------------------------")
    if selectionOne == "1":
      clear()
      # Tampilkan peta
      printMap(mapArr)
      # Untuk spasi di terminal (looks less crowded!)
      print("----------------------------------------------------------------")
    if selectionOne == "3":
      mapArr = getOptimizedMatrix()
      loop1 = False
      clear()
      print("Terima kasih telah menggunakan program kami!")

  # run program navigasi
  if loop1 == True:
    clear()
    daftar_gedung()
    mapArr = getOptimizedMatrix()
    print("")
    print("Gunakan tabel index nomor di atas untuk input tempat asal dan tujuan Anda di bawah.")
    print("Contoh : Jika ingin memilih 'Danau' inputlah '9'")
    print("")
    index_awal = int(input("Masukkan nomor tempat asal Anda: "))
    index_akhir = int(input("Masukkan nomor tempat tujuan Anda: "))
    print("\nLoading...")
    asal = koor_pintu[list_pintu[index_awal-1]]
    tujuan = koor_pintu[list_pintu[index_akhir-1]]

    dist, path = findShortestPathLength(mapArr, asal, tujuan)

    clear()
    
    for i in path:
      mapArr[i[0]][i[1]] = 'Z'
    printMap(mapArr)

    if (dist != -1):
        print(f"Jaraknya sekitar {dist*5.143:.2f} m")
        print(f"Sekitar {dist*5.143/1000 * 11.33:.0f} menit berjalan kaki")

    else:
        print("Shortest Path doesn't exist")

    print("----------------------------------------------------------------")
